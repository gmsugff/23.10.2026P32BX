package com.example.lifecycledemo

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var countPlus = 0
    private var countMinus = 0
    private lateinit var textViewPlus: TextView
    private lateinit var textViewMinus: TextView
    private lateinit var editTextName: EditText
    private lateinit var textViewGreeting: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textViewPlus = findViewById(R.id.textViewPlus)
        textViewMinus = findViewById(R.id.textViewMinus)
        editTextName = findViewById(R.id.editTextName)
        textViewGreeting = findViewById(R.id.textViewGreeting)

        findViewById<Button>(R.id.buttonPlus).setOnClickListener {
            countPlus++
            updateCounters()
        }

        findViewById<Button>(R.id.buttonMinus).setOnClickListener {
            countMinus--
            updateCounters()
        }

        findViewById<Button>(R.id.buttonSaveName).setOnClickListener {
            val name = editTextName.text.toString().trim()
            if (name.isNotEmpty()) {
                textViewGreeting.text = "Привет, $name!"
            }
        }

        if (savedInstanceState != null) {
            countPlus = savedInstanceState.getInt("KEY_PLUS", 0)
            countMinus = savedInstanceState.getInt("KEY_MINUS", 0)
            val savedName = savedInstanceState.getString("KEY_NAME")

            updateCounters()
            if (!savedName.isNullOrEmpty()) {
                textViewGreeting.text = savedName
            }
        }
    }

    private fun updateCounters() {
        textViewPlus.text = countPlus.toString()
        textViewMinus.text = countMinus.toString()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("KEY_PLUS", countPlus)
        outState.putInt("KEY_MINUS", countMinus)
        outState.putString("KEY_NAME", textViewGreeting.text.toString())
    }
}